#Pattern 5
class User_Defined_Class(object):
	def User_Defined_Method(self):
		pass

a = User_Defined_Class()
b = User_Defined_Class()

#Pattern 1
a.class_attribute = a

#Pattern 2
a.class_attribute = a.User_Defined_Method

#Pattern 3
a.class_attribute = b
b.class_attribute = a

#Pattern 4
a.class_attribute = [b]
b.class_attribute = a



func_globals = {}
code = compile('def User_Defined_Function():pass\n',
				'<string>','single')
exec(code,func_globals)
