#-*- coding: utf-8 -*-
# Copyright 2020 ibelie, Chen Jie, Joungtao. All rights reserved.
# Use of this source code is governed by The MIT License
# that can be found in the LICENSE file.

from __future__ import print_function

import objgraph
origin_short_repr = objgraph._short_repr
object_labels = {}
def custom_short_repr(obj):
	global object_labels
	if id(obj) in object_labels:
		return object_labels[id(obj)]
	return origin_short_repr(obj)
objgraph._short_repr = custom_short_repr

def _function_object(): pass
FunctionType = type(_function_object)

class User_Defined_Class(object):
	def User_Defined_Class_Method(self): pass

def draw__mro__():
	'class.__mro__造成的循环引用'
	objgraph.show_refs([User_Defined_Class, User_Defined_Class.__mro__],
		filter = lambda o: not (isinstance(o, dict) and '__dict__' in o),
		extra_info = lambda o: o is User_Defined_Class.__mro__ and '__mro__ : (User_Defined_Class, type)' or '',
		filename = '__mro__.png')

def draw_linked_list():
	'使用list实现循环链表造成的循环引用'
	a = ['node 1', None]
	b = ['node 2', None]
	c = ['node 3', None]
	a[1] = b
	b[1] = c
	c[1] = a
	objgraph.show_refs([a, b, c], filename = 'linked_list.png')

def draw_self_reference():
	'class的自引用'
	a = User_Defined_Class()
	a.class_attribute = a

	global object_labels
	object_labels[id(a)] = '<User_Defined_Class object at 0x01>'
	objgraph.show_refs([a],
		filter = lambda o: o is not User_Defined_Class and o != 'class_attribute',
		filename = 'self_reference.png')
	object_labels.clear()

def draw_couple_reference():
	'两个class相互引用'
	a = User_Defined_Class()
	b = User_Defined_Class()
	a.class_attribute = b
	b.class_attribute = a

	global object_labels
	object_labels[id(a)] = '<User_Defined_Class object at 0x01>'
	object_labels[id(b)] = '<User_Defined_Class object at 0x02>'
	objgraph.show_refs([a, b],
		filter = lambda o: o is not User_Defined_Class and o != 'class_attribute',
		filename = 'couple_reference.png')
	object_labels.clear()

def draw_couple_with_container():
	'两个class通过container相互引用'
	a = User_Defined_Class()
	b = User_Defined_Class()
	a.class_attribute = [b]
	b.class_attribute = a

	global object_labels
	object_labels[id(a)] = '<User_Defined_Class object at 0x01>'
	object_labels[id(b)] = '<User_Defined_Class object at 0x02>'
	objgraph.show_refs([a, b, a.class_attribute],
		filter = lambda o: o is not User_Defined_Class and o != 'class_attribute',
		extra_info = lambda o: isinstance(o, list) and 'or other container of tuple/dict/set' or '',
		filename = 'couple_with_container.png')
	object_labels.clear()

def draw_couple_with_method():
	'两个class通过method相互引用'
	a = User_Defined_Class()
	b = User_Defined_Class()
	a.class_attribute = b.User_Defined_Class_Method
	b.class_attribute = a

	global object_labels
	object_labels[id(a)] = '<User_Defined_Class object at 0x01>'
	object_labels[id(b)] = '<User_Defined_Class object at 0x02>'
	objgraph.show_refs([a, b, a.class_attribute],
		filter = lambda o: o is not User_Defined_Class and not isinstance(o, FunctionType) and o != 'class_attribute',
		filename = 'couple_with_method.png')
	object_labels.clear()

def draw_trinity_reference():
	'三个class相互引用'
	a = User_Defined_Class()
	b = User_Defined_Class()
	c = User_Defined_Class()
	a.class_attribute = b
	b.class_attribute = c
	c.class_attribute = a

	global object_labels
	object_labels[id(a)] = '<User_Defined_Class object at 0x01>'
	object_labels[id(b)] = '<User_Defined_Class object at 0x02>'
	object_labels[id(c)] = '<User_Defined_Class object at 0x03>'
	objgraph.show_refs([a, b, c],
		filter = lambda o: o is not User_Defined_Class and o != 'class_attribute',
		filename = 'trinity_reference.png')
	object_labels.clear()

def draw_func_globals():
	'function.func_globals造成的循环引用'
	func_globals = {}
	code = compile('def User_Defined_Function():pass\n', '<string>', 'single')
	exec(code, func_globals)

	f = func_globals['User_Defined_Function']
	global object_labels
	object_labels[id(f)] = '<function User_Defined_Function at 0x01>'
	objgraph.show_refs([f],
		filter = lambda o: o is not f.func_code and o is not f.func_closure and o is not f.__name__ and o is not f.func_globals['__builtins__'] and o != '__builtins__',
		filename = 'func_globals.png')
	object_labels.clear()

def draw_closure_leak():
	'闭包造成的循环引用'
	def f(n):
		if n < 1:
			f(n + 1)
	f(0)

	global object_labels
	object_labels[id(f)] = '<function Nested_Function at 0x01>'
	object_labels[id(f.func_closure[0])] = '<cell at 0x02: function object at 0x01>'
	objgraph.show_refs([f, f.func_closure, f.func_closure[0]],
		filter = lambda o: o is not f.func_code and o is not f.func_globals and o is not f.__module__ and o is not f.__name__ and o is not f.__defaults__,
		extra_info = lambda o: o is f.func_closure and 'closure tuple of cell variables' or '',
		filename = 'closure_leak.png')
	object_labels.clear()

def draw_instance_method():
	'属性引用instance method造成的循环引用'
	a = User_Defined_Class()
	a.class_attribute = a.User_Defined_Class_Method

	global object_labels
	object_labels[id(a)] = '<User_Defined_Class object at 0x01>'
	objgraph.show_refs([a, a.class_attribute],
		filter = lambda o: o is not User_Defined_Class and not isinstance(o, FunctionType) and o != 'class_attribute',
		filename = 'instance_method.png')
	object_labels.clear()

draw__mro__()
draw_linked_list()
draw_self_reference()
draw_couple_reference()
draw_couple_with_container()
draw_couple_with_method()
draw_trinity_reference()
draw_func_globals()
draw_closure_leak()
draw_instance_method()
